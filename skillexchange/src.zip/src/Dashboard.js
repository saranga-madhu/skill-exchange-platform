import { useState } from "react";
import Navbar1 from "./Navbar1";
import Sidebar from "./Sidebar";
import SkillCard from "./Skillcard";
import RequestCard from "./Requestcard";
import "./Dashboard.css";

function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <>
      {/* Navbar with menu button */}
      <Navbar1 onMenuClick={() => setSidebarOpen(!sidebarOpen)} />

      <div className="dashboard-layout">
        {/* Sidebar */}
        <Sidebar isOpen={sidebarOpen} />

        <div className="dashboard-content">
          <h1 className="dashboard-title">My Dashboard</h1>
          <p className="dashboard-subtitle">
            Manage your skills and track your exchanges
          </p>

          {/* My Skills */}
          <div className="skills-header">
            <h2>My Skills</h2>
            <button className="add-skill-btn">+ Add New Skill</button>
          </div>

          <div className="skills-grid">
            <SkillCard title="React Development" category="IT" students="5 students" />
            <SkillCard title="Guitar Lessons" category="Music" students="3 students" />
            <SkillCard title="Spanish Tutoring" category="Language" students="7 students" />
          </div>

          {/* Requests */}
          <h2 className="section-title">Incoming Requests</h2>

          <RequestCard name="Alex Johnson" skill="Python Programming" time="2 hours ago" />
          <RequestCard name="Emily Chen" skill="UI/UX Design" time="5 hours ago" />
          <RequestCard name="Mike Wilson" skill="French Conversation" time="1 day ago" />
        </div>
      </div>
    </>
  );
}

export default Dashboard;
