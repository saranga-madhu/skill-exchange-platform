import React, { useState } from "react"; 
import "./Register.css";
import Navbar1 from "./Navbar1";


function Register() {
  //  States for showing/hiding passwords
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  return (
    <>
      <Navbar1 /> {/* <-- use it here */}
    <div className="register-page">
      <h1 className="register-title">Join SkillExchange</h1>
      <p className="register-subtitle">
        Create your account and start exchanging skills today
      </p>

      <div className="register-card">
        <label>Full Name</label>
        <input type="text" placeholder="John Doe" />

        <label>Email Address</label>
        <input type="email" placeholder="your.email@university.edu" />

         {/* Password */}
          <label>Password</label>
          <div className="input-box">
            <input
              type={showPassword ? "text" : "password"}  // toggle type
              placeholder="••••••••"
            />
            <span
              className="eye-icon"
              onClick={() => setShowPassword(prev => !prev)}
              style={{ cursor: "pointer", marginLeft: "5px" }}
            >
              {showPassword ? "🙈" : "👁️"}
            </span>
          </div>

        {/* Confirm Password */}
          <label>Confirm Password</label>
          <div className="input-box">
            <input
              type={showConfirmPassword ? "text" : "password"}  // toggle type
              placeholder="••••••••"
            />
            <span
              className="eye-icon"
              onClick={() => setShowConfirmPassword(prev => !prev)}
              style={{ cursor: "pointer", marginLeft: "5px" }}
            >
              {showConfirmPassword ? "🙈" : "👁️"}
            </span>
          </div>


        <div className="terms">
          <input type="checkbox" />
          <spam>I agree to the Terms of Service and Privacy Policy</spam>
        </div>

        <button className="create-btn">Create Account</button>

        <p className="login-link">
          Already have an account? <span>Sign in</span>
        </p>
      </div>
    </div>
    </>
  );
}

export default Register;
