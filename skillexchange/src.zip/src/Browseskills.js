import { useState } from "react";
import Skillcard1 from "./skillcard1";
import Navbar1 from "./Navbar1";
import Categories from "./Categories";
import "./Browseskills.css";

const skills = [
  { title: "React Development", category: "IT", teacher: "Sarah Johnson", level: "Advanced" },
  { title: "Guitar Lessons", category: "Music", teacher: "Mike Chen", level: "Intermediate" },
  { title: "Spanish Tutoring", category: "Language", teacher: "Maria Garcia", level: "Native" },
  { title: "UI/UX Design", category: "Design", teacher: "Alex Kim", level: "Advanced" },
  { title: "Python Programming", category: "IT", teacher: "David Lee", level: "Expert" },
  { title: "Piano Basics", category: "Music", teacher: "Emma Wilson", level: "Intermediate" },
  { title: "French Conversation", category: "Language", teacher: "Pierre Dubois", level: "Native" },
  { title: "Graphic Design", category: "Design", teacher: "Lisa Brown", level: "Advanced" },
  { title: "Web Development", category: "IT", teacher: "Tom Anderson", level: "Advanced" },
];

function BrowseSkills() {
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredSkills =
    selectedCategory === "All"
      ? skills
      : skills.filter(skill => skill.category === selectedCategory);

  return (
    <>
    <Navbar1 />
    <div className="browse-container">
      <h1>Browse Skills</h1>
      <p>Find students who can teach you new skills</p>

      {/* Search Box */}
      <input
        type="text"
        placeholder="Search for skills or people..."
        className="search-box"
      />

      {/* Category Buttons */}
      <Categories
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
      />

      {/* Skill Cards */}
      <div className="skills-grid">
        {filteredSkills.map(skill => (
          <Skillcard1 key={skill.title} skill={skill} />
        ))}
      </div>
    </div>
    </>
  );
}

export default BrowseSkills;
