import React, { useState } from "react";  // ✅ useState import කරන්න
import { useNavigate } from "react-router-dom";
import "./Login.css";
import Navbar1 from "./Navbar1";

function Login() {
  const navigate = useNavigate();

  // ✅ State for showing/hiding password
  const [showPassword, setShowPassword] = useState(false);

  // Toggle function
  const togglePassword = () => {
    setShowPassword(prev => !prev);
  };

  return (
    <>
      <Navbar1 />

      <div className="login-container">
        <h1 className="login-title">Welcome Back</h1>
        <p className="login-subtitle">
          Sign in to continue your skill exchange journey
        </p>

        <div className="login-card">
          {/* Email */}
          <label>Email Address</label>
          <div className="input-box">
            <span className="icon">✉️</span>
            <input
              type="email"
              placeholder="your.email@university.edu"
            />
          </div>

          {/* Password */}
          <label>Password</label>
          <div className="input-box">
            <span className="icon">🔒</span>
            <input
              type={showPassword ? "text" : "password"}  // ✅ toggle type
              placeholder="••••••••"
            />
            <span 
              className="eye-icon" 
              onClick={togglePassword} 
              style={{ cursor: "pointer", marginLeft: "5px" }}
            >
              {showPassword ? "🙈" : "👁️"}  {/* eye icon toggle */}
            </span>
          </div>

          {/* Options */}
          <div className="login-options">
            <label className="remember">
              <input type="checkbox" />
              Remember me
            </label>

            <span className="forgot">Forgot password?</span>
          </div>

          {/* Button */}
          <button className="login-btn">➜ Sign In</button>

          <p className="register-link">
            Don’t have an account?
            <span onClick={() => navigate("/register")}>
              {" "}Create one now
            </span>
          </p>
        </div>
      </div>
    </>
  );
}

export default Login;
