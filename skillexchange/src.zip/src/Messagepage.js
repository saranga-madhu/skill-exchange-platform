import { useState } from "react";
import Navbar1 from "./Navbar1";
import ChatList from "./Chatlist";
import ChatWindow from "./Chatwindow";
import "./Messagepage.css";

const conversations = [
  {
    id: 1,
    name: "Sarah Johnson",
    lastMessage: "Thanks for the React tutorial!",
    messages: [
      { from: "them", text: "Hi! I saw your React development skill", time: "10:30 AM" },
      { from: "them", text: "Would you be available for a session this week?", time: "10:31 AM" },
      { from: "me", text: "Hello! Yes, I'd be happy to help", time: "10:40 AM" },
      { from: "me", text: "How about Thursday afternoon?", time: "10:40 AM" },
      { from: "them", text: "That works perfectly! What topics should I prepare?", time: "10:44 AM" }
  
    ]
  },
  {
    id: 2,
    name: "Mike Chen",
    lastMessage: "When can we schedule the guitar lesson?",
    messages: [
        { from: "them", text: "When can we schedule the guitar lesson?", time: "10:48 AM" }
    ]
  },
  {
    id: 3,
    name: "Maria Garcia",
    lastMessage: "Perfect! See you tomorrow",
    messages: [
        { from: "me", text: "Perfect! See you tomorrow", time: "10:48 AM" }
    ]
  }
];

function MessagePage() {
  const [selectedChat, setSelectedChat] = useState(conversations[0]);

  return (
    <>
      <Navbar1 />

      <div className="messages-container">
        <ChatList
          conversations={conversations}
          setSelectedChat={setSelectedChat}
          selectedChat={selectedChat}
        />

        <ChatWindow chat={selectedChat} />
      </div>
    </>
  );
}

export default MessagePage;
