function ChatWindow({ chat }) {
  if (!chat) {
    return <div className="chat-window">Select a conversation</div>;
  }

  return (
    <div className="chat-window">
      <div className="chat-header">
        <div className="avatar">{chat.name.charAt(0)}</div>
        <div>
          <h3>{chat.name}</h3>
          <span className="status">Active now</span>
        </div>
      </div>

      <div className="chat-messages">
        {chat.messages.map((msg, index) => (
          <div
            key={index}
            className={`message ${msg.from === "me" ? "me" : "them"}`}
          >
            {msg.text}
            <span className="time">{msg.time}</span>
          </div>
        ))}
      </div>

      <div className="chat-input">
        <input type="text" placeholder="Type a message..." />
        <button>Send</button>
      </div>
    </div>
  );
}

export default ChatWindow;
