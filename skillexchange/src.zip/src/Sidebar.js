import "./Sidebar.css";

function Sidebar() {
  return (
    <div className="sidebar">
      <div className="profile">
        <div className="avatar">👤</div>
        <h3>John Doe</h3>
        <p>Computer Science</p>
      </div>

      <div className="menu">
        <button className="menu-btn active">
          🏠 Dashboard
        </button>
        <button className="menu-btn">
          💡 My Skills
        </button>
        <button className="menu-btn">
          📩 Requests
        </button>
        <button className="menu-btn">
          💬 Messages
        </button>
        <button className="menu-btn">
          👤 Profile
        </button>
      </div>

      <button className="logout-btn">🔓 Logout</button>
    </div>
  );
}

export default Sidebar;
